library(ReplicationSuccess)

po <- seq(0.0001, 0.06, 0.0001)
to <- seq(-3, 3, 0.1)
priors <- c("conditional", "predictive", "EB")
c <- c(0.5, 1, 1.5, 2)
d <- c(0, 1)
alt <- c("two.sided", "greater")
shrinkage <- c(1, 0.5)

# extending plots from Held (2020)
par(mfrow = c(2, 2), las = 1)
for (i in seq_along(c)) {
  plot(po, powerSignificance(po = po, c = c[i], 
                             designPrior = priors[1],
                             alternative = alt[1]),
       type = "l", ylim = c(0, 1), main = bquote(c == .(c[i])),
       ylab = "Power")
  lines(po, powerSignificance(po = po, c = c[i], 
                              designPrior = priors[1],
                              alternative = alt[2]),
        lty = 1, col = "darkgrey")
  lines(po, powerSignificance(po = po, c = c[i], 
                              designPrior = priors[2],
                              alternative = alt[1]),
        lty = 2)
  lines(po, powerSignificance(po = po, c = c[i], 
                              designPrior = priors[2],
                              alternative = alt[2]),
        lty = 2, col = "darkgrey")
  lines(po, powerSignificance(po = po, c = c[i], 
                              designPrior = priors[3],
                              alternative = alt[1]),
        lty = 3)
  lines(po, powerSignificance(po = po, c = c[i], 
                              designPrior = priors[3],
                              alternative = alt[2]),
        lty = 3, col = "darkgrey")
  legend("bottomleft", legend = priors, 
         lty = c(1, 2, 3), bty = "n", cex = 0.5)
  legend("topright", legend = c("two-sided", "one-sided"), 
         lty = 1, col = c(1, "darkgrey"), bty = "n", cex = 0.5)
}