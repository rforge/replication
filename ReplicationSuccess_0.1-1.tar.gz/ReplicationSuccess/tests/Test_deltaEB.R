library(ReplicationSuccess)

posteriorEB <- function(to, tr, c, sigma2r){
    sigma2o <- c*sigma2r
    thetao <- to*sqrt(sigma2o)
    thetar <- tr*sqrt(sigma2r)
    delta <- deltaEB(to=to, tr=tr, c=c)
    posteriorVar <- 1/(delta*sigma2o+sigma2r)
    posteriorMean <- (thetar/sigma2r+delta*thetao/sigma2o)*posteriorVar
    res <- cbind(posteriorMean, posteriorVar)
    colnames(res) <- c("Mean", "Variance")
    return(res)
}

to <- 4
tr <- seq(0, 6, .1)
c <- 3

results <- matrix(NA, ncol=2, nrow=length(tr))
delta <- numeric()
p <- numeric()
for(i in seq_len(length(tr))){
    delta[i] <- deltaEB(to=to, tr=tr[i], c=c)
    results[i,] <- posteriorEB(to=to, tr=tr[i], c=c, sigma2r=1)
    p[i] <- pSceptical(to=to, tr=tr[i], c=c)
}
    
par(las=1)
matplot(tr, cbind(delta, results, p), type="l", lty=1, lwd=2, ylim=c(0, 4))
legend("topleft", col=1:4, lty=1, lwd=2, legend=c("DeltaEB", "Mean", "Variance", "pSceptical"))
