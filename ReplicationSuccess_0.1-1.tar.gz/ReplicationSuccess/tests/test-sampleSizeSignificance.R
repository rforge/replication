library(ReplicationSuccess)

po <- seq(0.0001, 0.055, 0.0001)
priors <- c("conditional", "predictive", "EB")
d <- c(0, 1)
alt <- c("less", "greater", "two.sided")


plot(po, sampleSizeSignificance(po = po, 
                                power = 0.8, 
                                level = 0.05,
                                designPrior = priors[2],
                                alternative = "two.sided"),
     type = "l", main = bquote(c == 1), log = "xy",
     ylab = "Power", lty = 2, ylim = c(0.25, 50))
lines(po, sampleSizeSignificance(po = po, 
                                 power = 0.8, 
                                 level = 0.05,
                                 designPrior = priors[1],
                                 alternative = "two.sided"),
      lty = 1)
lines(po, sampleSizeSignificance(po = po, 
                                 power = 0.8, 
                                 level = 0.05,
                                 designPrior = priors[3],
                                 alternative = "two.sided"),
      lty = 3)
legend("bottomleft", legend = priors, 
       lty = c(1, 2, 3), bty = "n", cex = 0.5)