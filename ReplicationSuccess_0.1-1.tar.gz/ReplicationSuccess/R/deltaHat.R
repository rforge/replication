
deltaEB <- function(po=NULL, pr=NULL,
                    to=p2t(po, alternative=alternative),
                    tr=p2t(pr, alternative=alternative),
                    c, alternative="two.sided"){
    term1 <- (tr/sqrt(c)-to)^2
    term2 <- 1+1/c
    term3 <- -1/c
    res <- pmax(term1, term2) + term3
    return(1/res)
}
    
posteriorEB <- function(to, tr, c, sigma2r){
    sigma2o <- c*sigma2r
    thetao <- to*sqrt(sigma2o)
    thetar <- tr*sqrt(sigma2r)
    delta <- deltaHatEB(to=to, tr=tr, c=c)
    posteriorVar <- 1/(delta*sigma2o+sigma2r)
    posteriorMean <- (thetar/sigma2r+delta*thetao/sigma2o)*posteriorVar
    res <- cbind(posteriorMean, posteriorVar)
    colnames(res) <- c("Mean", "Variance")
    return(res)
}

