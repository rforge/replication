## ----"knitr-options", echo = FALSE---------------------------------------
library(knitr)
opts_chunk$set(size = "small",
               fig.height = 4,
               fig.align = "center",
               cache = FALSE,
               message = FALSE,
               warning = FALSE)

## ----"data-loading"------------------------------------------------------
library(ReplicationSuccess)
data("RProjects")
str(RProjects)

## computing zo, zr, c
RProjects$zo <- with(RProjects, fiso/se_fiso)
RProjects$zr <- with(RProjects, fisr/se_fisr)
RProjects$c <- with(RProjects, se_fiso^2/se_fisr^2)

## computing one-sided p-values for alternative = "greater"
RProjects$po1 <- z2p(z = RProjects$zo, alternative = "greater")
RProjects$pr1 <- z2p(z = RProjects$zr, alternative = "greater")

## ----"plot-projects", fig.height = 5-------------------------------------
## plots of effect estimates
par(mfrow = c(2, 2), las = 1, mai = rep(0.65, 4))
for (p in unique(RProjects$project)) {
    data_project <- subset(RProjects, project == p)
    significant <- ifelse(data_project$pr < 0.05, "darkred", "black")
    plot(rr ~ ro, data = data_project, ylim = c(-0.5, 1), col = significant,
         xlim = c(-0.1, 1), main = p, xlab = expression(italic(r)[o]), 
         cex = 0.7, pch = 19, ylab = expression(italic(r)[r]))
    legend("topleft", legend = "significant", pch = 20, col = "darkred", bty = "n")
    abline(h = 0, lty = 2)
    abline(a = 0, b = 1, col = "grey")
}

## ------------------------------------------------------------------------
for (p in unique(RProjects$project)) {
    data_project <- subset(RProjects, project == p)
    significant_O <- data_project$po < 0.05
    significant_R <- data_project$pr < 0.05
    success <- (significant_O == TRUE) & (significant_R == TRUE) & 
        (sign(data_project$fiso) == sign(data_project$fisr))
    cat(paste0(p, ": \n"))
    cat(paste0(round(mean(significant_O)*100, 1), "% original studies significant (", 
               sum(significant_O), "/", length(significant_O), ")\n"))
    cat(paste0(round(mean(significant_R)*100, 1), "% replications significant (", 
               sum(significant_R), "/", length(significant_R), ")\n"))
    cat(paste0(round(mean(success)*100, 1), 
               "% both studies significant in the same direction (", 
               sum(success), "/", length(success), ")\n \n"))
}

## ------------------------------------------------------------------------
sampleSizeSignificance(zo = 2.5, power = 0.8, level = 0.05, designPrior = "conditional")
sampleSizeSignificance(zo = 2.5, power = 0.8, level = 0.05, designPrior = "predictive")
sampleSizeSignificance(zo = 2.5, power = 0.8, level = 0.05, designPrior = "conditional",
                       shrinkage = 0.75)

## ----"plot-powerSignificance", echo = FALSE, fig.height = 4--------------
po <- seq(0.0001, 0.05, 0.0001)

## plot power
plot(po, powerSignificance(zo = p2z(po), designPrior = "conditional")*100,
     type = "l", ylim = c(0, 100), lwd = 1.5, ylab = "Power (%)", 
     xlab = expression(italic(p)[o]), las = 1)
axis(side = 3, at = seq(0.0, 0.05, by = 0.01), 
     labels = c("", round(p2z(p = seq(0.01, 0.05, by = 0.01)), 2)))
mtext(text = expression(paste("|", italic(z)[o], "|")), side = 3, line = 2)
abline(h = 50, col = "#333333B3", lty = 3)
lines(po, powerSignificance(zo = p2z(po), designPrior = "predictive")*100, lwd = 2, lty = 2)
legend("topright", legend = c("conditional", "predictive"), 
       title = "Design prior", lty = c(1, 2), lwd = 1.5, bty = "n")

## ----"plot-sampleSizeSignificance", echo = FALSE, fig.height = 4---------
## plot sample size 
plot(po, sampleSizeSignificance(zo = p2z(po), designPrior = "conditional", power = 0.8),
     type = "l", ylim = c(0.5, 10), log = "y", lwd = 1.5, 
     ylab = expression(paste("Relative sample size ", n[r]/n[o])),
     xlab = expression(italic(p)[o]), las = 1)
axis(side = 3, at = seq(0.0, 0.05, by = 0.01), 
     labels = c("", round(p2z(p = seq(0.01, 0.05, by = 0.01)), 2)))
mtext(text = expression(paste("|", italic(z)[o], "|")), side = 3, line = 2)
abline(h = 1, col = "#333333B3", lty = 3)
lines(po, sampleSizeSignificance(zo = p2z(po), designPrior = "predictive", power = 0.8), 
      lwd = 2, lty = 2)
legend("topleft", legend = c("conditional", "predictive"), 
       title = "Design prior", lty = c(1, 2), lwd = 1.5, bty = "n")

## ----"plot-predictionInterval", fig.height = 6---------------------------
## compute prediction intervals for replication projects
par(mfrow = c(2, 2), las = 1, mai = rep(0.65, 4))
for (p in unique(RProjects$project)) {
    data_project <- subset(RProjects, project == p)
    PI <- predictionInterval(zo = data_project$zo, c = data_project$c)
    ## multiplying by standard error to transform to Fisher z-scale
    PI <- PI*data_project$se_fisr 
    ## transforming back to correlation scale 
    PI <- tanh(PI)
    within <- (data_project$rr < PI$upper) & (data_project$rr > PI$lower)
    coverage <- mean(within)
    color <- ifelse(within == TRUE, "#333333B3", "#8B0000B3")
    study <- seq(1, nrow(data_project))
    plot(data_project$rr, study, col = color, pch = 20, 
         xlim = c(-0.5, 1), xlab = expression(italic(r)[r]), ylab = "Study",
         main = paste0(p, ": ", round(coverage*100, 0), "% coverage"))
    arrows(PI$lower, study, PI$upper, study, length = 0.02, angle = 90, code = 3, col = color)
    abline(v = 0, lty = 3)
}

## ----"plot-pSceptical", echo = FALSE, fig.height = 4---------------------
## Functions
ssv <- function(zo, so, a) {
    tau2 <- so^2/(zo^2/qnorm(p = a/2, lower.tail = FALSE)^2 - 1)
    return(tau2)
}

## Parameters and computations
options(scipen = 5)
theta_o <- 0.57
theta_r <- 0.33
so <- 0.165
sr <- 0.165
c <- so^2/sr^2
zo <- theta_o/so
zr <- theta_r/sr
alpha <- 0.05
za <- qnorm(p = alpha/2, lower.tail = FALSE)
ps <- signif(pSceptical(zo = zo, zr = zr, c = c), 2)
ps_tilde <- signif(pSceptical(zo = zo, zr = zr, c = c, 
                              alternative = "one.sided"), 2)
tau <- sqrt(ssv(zo, so, alpha))
s2_p <- 1/(1/so^2 + 1/tau^2)
mu_p <- s2_p*theta_o/so^2



## Plot
df <- data.frame(estimate = factor(c("Original Study", 
                                     "Posterior", 
                                     "Sceptical Prior", 
                                     "Replication Study"),
                                   levels = c("Original Study", 
                                              "Posterior", 
                                              "Sceptical Prior", 
                                              "Replication Study")),
                 theta = c(theta_o, 
                           mu_p, 
                           0, 
                           theta_r),
                 lower = c(theta_o - za*so,
                           mu_p - za*sqrt(s2_p), 
                           0 - za*tau, 
                           theta_r - za*sr),
                 upper = c(theta_o + za*so, 
                           mu_p + za*sqrt(s2_p), 
                           0 + za*tau,
                           theta_r + za*sr),
                 p = c(signif(2*pnorm(q = zo, lower.tail = FALSE), 1), 
                       NA, 
                       NA, 
                       signif(2*pnorm(q = zr, lower.tail = FALSE), 2)))

plot.default(x = df$estimate, y = df$theta, type = "p", ylim = c(-0.3, 1), 
             xlim = c(0.4, 4.5), xaxt = "n", pch = 20, xlab = "", cex = 1.5,
             ylab = "Effect size", las = 1)
axis(side = 1, at = df$estimate, labels = levels(df$estimate), cex.axis = 0.8)
abline(h = 0, lty = 2)
arrows(x0 = as.numeric(df$estimate), y0 = df$lower, y1 = df$upper,
       length = 0.05, angle = 90, code = 3)
text(x = 4 + 0.3, y = 0.9, labels = bquote(italic(p)[S] == .(ps_tilde)), col = 2)
text(x = 0.6, y = theta_o + 0.05, labels = bquote(hat(theta)[o] == .(theta_o)))
text(x = 3.65, y = theta_r + 0.05, labels = bquote(hat(theta)[r] == .(theta_r)))
text(x = 0.65, y = theta_o - 0.1, labels = bquote(italic(p)[o] == .(df$p[1])))
text(x = 3.7, y = theta_r - 0.1, labels = bquote(italic(p)[r] == .(df$p[4])))
points(x = 2, y = 0, col = 2)
arrows(x0 = 1.8, x1 = 1.97, y0 = -0.2, y1 = -0.03, col = 2, length = 0.1)
text(x = 1.7, y = -0.25, labels = "fixed at zero", col = 2, cex = 0.8)

## ----"threshold-p-sceptical"---------------------------------------------
## computing nominal, controlled, and liberal thresholds for one-sided sceptical p-value
(thresh_nom <- thresholdSceptical(level = 0.025, alternative = "one.sided", 
                                  type = "nominal"))
(thresh_contr <- thresholdSceptical(level = 0.025, alternative = "one.sided", 
                                    type = "controlled"))
(thresh_lib <- thresholdSceptical(level = 0.025, alternative = "one.sided", 
                                  type = "liberal"))

## ----"plot-pSceptical-projects", fig.height = 4--------------------------
## computing one.sided sceptical p-value for replication projects
RProjects$ps <- with(RProjects, 
                     pSceptical(zo = zo, zr = zr, c = c, 
                                alternative = "one.sided"))
boxplot(ps ~ project, data = RProjects, las = 1, cex.axis = 0.7, ylim = c(0, 1),
        xlab = "Project", ylab = expression(italic(p)[S]), outline = FALSE)
abline(h = thresh_contr, lty = 3)
stripchart(ps ~ project, data = RProjects, vertical = TRUE, add = TRUE,
           pch = 19, method = "jitter", jitter = 0.2, cex = 0.6)

for (p in unique(RProjects$project)) {
    data_project <- subset(RProjects, project == p)
    cat(paste0(p, ": \n"))
    success_scept <- (data_project$ps < thresh_contr)
    cat(paste0(round(mean(success_scept)*100, 2), 
               "% smaller than 0.0653 (one-sided sceptical p-value) \n"))
    success_tradit <- (data_project$po1 < 0.025) & (data_project$pr1 < 0.025)
    cat(paste0(round(mean(success_tradit)*100, 2), 
               "% smaller than 0.025 (both one-sided traditional p-values) \n"))
    if(sum(success_scept != success_tradit) > 0){
        discrep <- data_project[(success_scept != success_tradit), 
                                c("ro", "rr", "c", "po1", "pr1", "ps")]
        ## print effect estimates, 1sided p-values, and c of discrepant studies
        cat("Discrepant studies: \n")
        print(signif(discrep, 2), row.names = FALSE)
  }
  cat("\n \n")
}

## ------------------------------------------------------------------------
sampleSizeReplicationSuccess(zo = 2.5, power = 0.8, level = thresh_contr,
                             alternative = "one.sided",
                             designPrior = "conditional")
sampleSizeReplicationSuccess(zo = 2.5, power = 0.8, level = thresh_contr,
                             alternative = "one.sided",
                             designPrior = "predictive")

## ----"plot-powerReplicationSuccess", echo = FALSE, fig.height = 4--------
## plot power
plot(po, powerReplicationSuccess(zo = p2z(po), 
                                 designPrior = "conditional",
                                 level = thresh_contr, 
                                 alternative = "one.sided")*100,
     type = "l", ylim = c(0, 100), lwd = 1.5, ylab = "Power (%)", las = 1,
     xlab = expression(italic(p)[o]))
axis(side = 3, at = seq(0.0, 0.05, by = 0.01), 
     labels = c("", round(p2z(p = seq(0.01, 0.05, by = 0.01)), 2)))
mtext(text = expression(paste("|", italic(z)[o], "|")), side = 3, line = 2)
lines(po, powerReplicationSuccess(zo = p2z(po), 
                                  designPrior = "predictive",
                                  level = thresh_contr, 
                                  alternative = "one.sided")*100, 
      lwd = 2, lty = 2)
legend("topright", legend = c("conditional", "predictive"), 
       title = "Design prior", lty = c(1, 2), lwd = 1.5, bty = "n")
abline(h = 50, lty = 3)

## ----"plot-sampleSizeReplicationSuccess", echo = FALSE, fig.height = 4----
po <- seq(0.0001, 0.05, 0.0001)

## plot sample size 
plot(po, 
     sampleSizeReplicationSuccess(zo = p2z(po), 
                                  designPrior = "conditional",
                                  level = thresh_contr, 
                                  alternative = "one.sided", 
                                  power = 0.8),
     type = "l", log = "y", lwd = 1.5, las = 1, ylim = c(0.5, 50),
     ylab = expression(paste("Relative sample size ", n[r]/n[o])),
     xlab = expression(italic(p)[o]), yaxt = "n")
axis(side = 2, las = 1, at = c(0.5, 1, 2, 5, 10, 20, 50), 
     labels = c("1/2", "1", "2", "5", "10", "20", "50"))
abline(h = 1, lty = 3)
axis(side = 3, at = seq(0.0, 0.05, by = 0.01), 
     labels = c("", round(p2z(p = seq(0.01, 0.05, by = 0.01)), 2)))
mtext(text = expression(paste("|", italic(z)[o], "|")), side = 3, line = 2)
lines(po, sampleSizeReplicationSuccess(zo = p2z(po),
                                       designPrior = "predictive", 
                                       level = thresh_contr, 
                                       alternative = "one.sided", 
                                       power = 0.8), 
      lwd = 2, lty = 2)
legend("topleft", legend = c("conditional", "predictive"), 
       title = "Design prior", lty = c(1, 2), lwd = 1.5, bty = "n")

## ----echo = FALSE--------------------------------------------------------
data("SSRP")
par(las = 1)
intpow_cond <- with(SSRP, powerSignificanceInterim(zo = fiso/se_fiso, zi = fisi/se_fisi, c = ni/no, 
                                                   f = ni/nr, designPrior = "conditional"))
intpow_pred <- with(SSRP, powerSignificanceInterim(zo = fiso/se_fiso, zi = fisi/se_fisi, c = ni/no, 
                                                   f = ni/nr, designPrior = "predictive"))
plot(intpow_cond*100, intpow_pred*100,  
     xlab = "Conditional power (in %)", 
     ylab = "Predictive power (in %)", 
     pch = 20,
     cex = 1.5,
     xlim = c(80,100), 
     ylim = c(0,100))
abline(a = 0, b = 1, col = "grey")

## ----"shrinkage", echo = FALSE, fig.height = 3.5-------------------------
formatpval <- function (x, break.eps = 1e-04, break.middle = 0.01, na.form = "NA", 
    ...) 
{
    format1Pval <- function(pv) {
        if (is.na(pv)) {
            na.form
        }
        else if (pv < break.eps) {
            paste("<", format(break.eps, scientific = FALSE))
        }
        else {
            largep <- pv >= break.middle
            format(pv, digits = 1 + largep, nsmall = 1 + largep, 
                scientific = FALSE, ...)
        }
    }
    vapply(X = x, FUN = format1Pval, FUN.VALUE = "", USE.NAMES = TRUE)
}

zo <- seq(0, 4, 0.01)
s <- pmax(1 - 1/zo^2, 0)
plot(zo, s, type = "l", ylim = c(0, 1), las = 1,
     xlab = expression(paste("|",italic(z)[o],"|")), ylab = "Shrinkage factor")
axis(side = 3, at = seq(0, 4, by = 1), labels = formatpval(z2p(seq(0, 4, by = 1))))
mtext(text = expression(italic(p)[o]), side = 3, line = 2)

